Welcome to IsoCam

here are a few information, which are important to read:

1.
When registering the hardware dongle please insert at least 5 digits in line "name" and "company". Enter at least 10 digit in line "telephone number".

Do not remove the hardware dongle while the software Isocam is running. This will destroy the dongle!!

Keep the dongle in a safe place.

2.
This CD contains IsoCam 5.0. This versions runs on all current Windows operating systems including windows 7 (64 bit). When you install this software, your key will be automatically upgraded to this version and will not work with older IsoCam versions anymore.

3.
SMARTKEY DRIVER INSTALLATION
----------------------------

This package contains an installation library for the SmartKey drivers. This 
library can be used to install the SmartKey drivers with a simple function call.

You have to activate the Smart Key Drivers manually !!!

To do so, follow these steps:

open directory c - programs - IsoCam - keys
double click on the file "sdi.exe"
a menu appears, click on register "usb" and then on "install".
exit with OK!


======================================================
THE SDI DRIVER is replacement for old GSS2 drivers !!
======================================================


FILES
-----

Sdi.exe
Sdiline.exe
	Simple visual and command line applications that use the library to 
	install the SmartKey drivers. 

skeyinst.dll
	Library for the automatic installation of the SmartKey drivers.

skeyinst-html.zip
skeyinst.chm
	Documentation of the skeyinst.dll library in CHM and HTML format.

skeyinst-is631.zip
skeyinst-is701.zip
	InstallShield 6.31 e 7.01 examples for the skeyinst.dll library.

skeyinst.bas
	VisualBasic interface for the skeyinst.dll library.

skeyinst.h
skeyinst.lib
	C interface for the skeyinst.dll library.

eugss2k.sys
eugssnt.sys
eugssxp.sys
eusk2par.sys
skeyusb.inf
skeyusb.sys
skeyusbnt.inf
skeyusbnt.sys
eusk3usb.inf
eusk3usb.sys
eusk3usb.cat
usbdrv.inf
usbdrv.sys
psapi.dll
	Files required for the SmartKey Drivers installation.


FEATURES
--------

For any driver the SDI tool allow three different operations:

* Install
Installation or upgrade of the driver.

* Uninstall
Uninstallation of the driver.

* Remove/Forced Uninstall
Force and complete removal of the driver to resolve erroneous install conditions.
This operation must not be used in normal conditions, but only to recover from
installation errors.
After this operation it's always required to reboot.

EUTRON

Internet : http://www.smartkey.eutron.com
Helpdesk email : helpdesk@eutron.com
Commercial email : info@eutron.com
Commercial phone : +39-035697080
Fax : +39-035697092